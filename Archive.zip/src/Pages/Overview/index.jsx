import React from "react";
const Overview = () => {
    return (
<div>
<h1 className="home">HOME / ABOUT US</h1>
  <h1 className="welcome2"> Who Are You</h1>
      <h1 className="welcome"> Wellcome to Online Site</h1><br></br>
      <h1 className="welcome1">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt labor<br></br> et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris <br></br>ut aliquip ex ea commo consequat irure</h1>
      <div className="shopping">
       <div className="watches" >
       <img src={"https://template.hasthemes.com/flone/flone/assets/img/banner/banner-1.jpg"} className="watch"/>
       <img src={"https://template.hasthemes.com/flone/flone/assets/img/banner/banner-2.jpg"} className="watch" />
       <img src={"https://template.hasthemes.com/flone/flone/assets/img/banner/banner-3.jpg"} className="watch" />
       </div>
<div className="textonpic">
        <p className="pic1">Watch</p>
        <p className="pic2">Bag</p>
        <p className="pic3">Sunglass</p>
        <p className="pic4">Starting at $99.50</p>
        <p className="pic5">Starting at $99.50</p>
        <p className="pic6">Starting at $99.50</p>

      </div>

      </div>
      
      
      
      
      </div>
    )
    
  };
  
  export default Overview;
  