
const BagBox = ({ children }) => {
  
    return (
      <>
      <div onClick={alert("Hello World!")} className="overlay"> </div>
        <div  className="bagBox" >
              <img  src="https://template.hasthemes.com/flone/flone/assets/img/cart/cart-1.png"></img>
              <div className="text">T- Shart & Jeans<br></br><br></br><br></br><br></br><br></br>
              Qty: 02<br></br><br></br><br></br><br></br><br></br>
              $260.00</div>
        <div className="borderline">
        </div>
              <img src="https://template.hasthemes.com/flone/flone/assets/img/cart/cart-2.png"></img>
              <div className="text1">    T- Shart & Jeans<br></br><br></br><br></br><br></br><br></br>
              Qty: 02<br></br><br></br><br></br><br></br><br></br>
              $260.00</div>
              <div className="borderline"> 
  
              </div>
              <h1>Shipping:</h1>
              <h1>Total:</h1>
              <button>View Card</button><br></br><br></br><br></br>
              <button> Check Out</button>
              
        </div>
        
        </>
    )
  };
  
  export default BagBox;